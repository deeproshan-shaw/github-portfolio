// Loads profile.json (provided by user) and renders About, Experience, Education, Skills,
// Certifications, Languages, Contact. Also loads GitHub repos (if a username is configured).
(async () => {
  const html = document.documentElement;
  const defaultUsername = html.dataset.username || "deeproshan-shaw";

  const avatar = document.getElementById("avatar");
  const linkedinLink = document.getElementById("linkedin-link");
  const websiteLink = document.getElementById("website-link");
  const displayNameEl = document.getElementById("display-name");
  const projectsGrid = document.getElementById("projects-grid");
  const projectsMore = document.getElementById("projects-more");
  const currentYear = document.getElementById("current-year");
  const heroTitle = document.getElementById("hero-title");
  const aboutText = document.getElementById("about-text");
  const skillList = document.getElementById("skill-list");
  const experienceList = document.getElementById("experience-list");
  const educationList = document.getElementById("education-list");
  const contactList = document.getElementById("contact-list");
  const certList = document.getElementById("cert-list");
  const languageList = document.getElementById("language-list");
  const brandName = document.getElementById("brand-name");
  const pageTitle = document.getElementById("page-title");
  const footerName = document.getElementById("footer-name");
  const locationMeta = document.getElementById("location-meta");

  currentYear.textContent = new Date().getFullYear();

  // Defaults
  displayNameEl.textContent = "Deeproshan Shaw";
  avatar.src = `https://avatars.githubusercontent.com/${defaultUsername}?v=4`;
  heroTitle.setAttribute("aria-label", `Hi — I'm ${displayNameEl.textContent}`);
  brandName.textContent = displayNameEl.textContent;
  pageTitle.textContent = `${displayNameEl.textContent} — Portfolio`;
  footerName.textContent = displayNameEl.textContent;

  // Small nav toggle
  const navToggle = document.getElementById("nav-toggle");
  const siteNav = document.getElementById("site-nav");
  navToggle.addEventListener("click", () => {
    const expanded = navToggle.getAttribute("aria-expanded") === "true";
    navToggle.setAttribute("aria-expanded", String(!expanded));
    siteNav.style.display = expanded ? "" : "flex";
  });

  // Smooth scrolling for internal links
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener("click", (e) => {
      const target = document.querySelector(a.getAttribute("href"));
      if (target) {
        e.preventDefault();
        target.scrollIntoView({behavior:"smooth", block:"start"});
      }
    });
  });

  // Attempt to load profile.json
  async function loadProfileJson() {
    try {
      const res = await fetch("profile.json");
      if (!res.ok) return null;
      const json = await res.json();
      return json;
    } catch (e) {
      console.warn("Could not load profile.json:", e);
      return null;
    }
  }

  function escapeHtml(s = "") {
    return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  }

  function renderProfile(profile) {
    if (!profile) return;
    // Name & headline
    if (profile.name) {
      displayNameEl.textContent = profile.name;
      brandName.textContent = profile.name;
      pageTitle.textContent = `${profile.name} — Portfolio`;
      footerName.textContent = profile.name;
      heroTitle.setAttribute("aria-label", `Hi — I'm ${profile.name}`);
    }
    if (profile.headline) {
      const heroSub = document.getElementById("hero-sub");
      heroSub.textContent = profile.headline;
    }
    if (profile.summary) {
      aboutText.textContent = profile.summary;
    }
    // Location
    if (profile.location) {
      const parts = [profile.location.city, profile.location.region, profile.location.country].filter(Boolean);
      locationMeta.textContent = parts.join(", ");
    }
    // Avatar
    if (profile.avatar) {
      avatar.src = profile.avatar;
    }
    // Contact
    contactList.innerHTML = "";
    const c = profile.contact || {};
    if (c.phone_work) {
      const li = document.createElement("li");
      li.innerHTML = `Phone (Work): <a href="tel:${escapeHtml(c.phone_work)}">${escapeHtml(c.phone_work)}</a>`;
      contactList.appendChild(li);
    }
    if (c.email) {
      const li = document.createElement("li");
      li.innerHTML = `Email: <a href="mailto:${escapeHtml(c.email)}">${escapeHtml(c.email)}</a>`;
      contactList.appendChild(li);
      const emailLink = document.getElementById("email-link");
      if (emailLink) {
        emailLink.href = `mailto:${c.email}`;
        emailLink.textContent = c.email;
      }
    }
    if (c.linkedin) {
      linkedinLink.href = c.linkedin;
      linkedinLink.textContent = c.linkedin.replace(/^https?:\/\//, "");
    }
    if (c.website) {
      websiteLink.href = c.website;
      websiteLink.textContent = c.website;
    }

    // Skills
    skillList.innerHTML = "";
    if (Array.isArray(profile.top_skills)) {
      profile.top_skills.forEach(s => {
        const li = document.createElement("li");
        li.textContent = s;
        skillList.appendChild(li);
      });
    }

    // Languages
    languageList.innerHTML = "";
    if (Array.isArray(profile.languages)) {
      profile.languages.forEach(lang => {
        const li = document.createElement("li");
        li.textContent = `${lang.name} — ${lang.proficiency || ""}`;
        languageList.appendChild(li);
      });
    }

    // Certifications
    certList.innerHTML = "";
    if (Array.isArray(profile.certifications)) {
      profile.certifications.forEach(cert => {
        const li = document.createElement("li");
        li.textContent = cert;
        certList.appendChild(li);
      });
    }

    // Experience
    experienceList.innerHTML = "";
    if (Array.isArray(profile.experience)) {
      profile.experience.forEach(exp => {
        const el = document.createElement("article");
        el.className = "card";
        const dates = [exp.start, exp.end].filter(Boolean).join(" — ");
        el.innerHTML = `
          <h3>${escapeHtml(exp.title || "")} <small class="muted"> @ ${escapeHtml(exp.company || "")}</small></h3>
          <div class="meta muted">${escapeHtml(dates)} ${exp.duration ? ` • ${escapeHtml(exp.duration)}` : ""} ${exp.location ? ` • ${escapeHtml(exp.location)}` : ""}</div>
          <p>${escapeHtml(exp.description || "")}</p>
        `;
        experienceList.appendChild(el);
      });
    }

    // Education
    educationList.innerHTML = "";
    if (Array.isArray(profile.education)) {
      profile.education.forEach(ed => {
        const el = document.createElement("article");
        el.className = "card";
        const years = [ed.start_year || ed.start || "", ed.end_year || ed.end || ""].filter(Boolean).join(" — ");
        el.innerHTML = `
          <h3>${escapeHtml(ed.institution || "")} <small class="muted">${escapeHtml(ed.degree || "")}${ed.field ? ` — ${escapeHtml(ed.field)}` : ""}</small></h3>
          <div class="meta muted">${escapeHtml(years)}</div>
        `;
        educationList.appendChild(el);
      });
    }
  }

  // Load GitHub repos (if username available)
  async function loadRepos(username) {
    if (!username) return;
    try {
      const res = await fetch(`https://api.github.com/users/${username}/repos?sort=updated&per_page=12`);
      if (!res.ok) throw new Error("GitHub API error");
      const repos = await res.json();
      if (!Array.isArray(repos) || repos.length === 0) {
        projectsGrid.innerHTML = '<p class="muted">No public repositories found.</p>';
        return;
      }

      const filtered = repos.filter(r => !r.fork).slice(0, 12);
      filtered.forEach(r => {
        const card = document.createElement("article");
        card.className = "card";
        const desc = r.description ? `<p>${escapeHtml(r.description)}</p>` : "";
        const language = r.language ? `<span class="meta">${escapeHtml(r.language)}</span>` : "";
        card.innerHTML = `
          <h3><a href="${r.html_url}" target="_blank" rel="noopener">${escapeHtml(r.name)}</a></h3>
          ${desc}
          <div class="meta">${language} • Updated ${timeAgo(new Date(r.updated_at))}</div>
        `;
        projectsGrid.appendChild(card);
      });

      if (repos.length > filtered.length) {
        projectsMore.innerHTML = `<a class="muted" href="https://github.com/${username}?tab=repositories" target="_blank" rel="noopener">View more repositories on GitHub</a>`;
      }
    } catch (err) {
      console.error(err);
      projectsGrid.innerHTML = `<p class="muted">Could not load repositories from GitHub.</p>`;
    }
  }

  function timeAgo(date) {
    const secs = Math.floor((Date.now() - date.getTime())/1000);
    if (secs < 60) return `${secs}s`;
    const mins = Math.floor(secs/60); if (mins < 60) return `${mins}m`;
    const hrs = Math.floor(mins/60); if (hrs < 24) return `${hrs}h`;
    const days = Math.floor(hrs/24); if (days < 30) return `${days}d`;
    const months = Math.floor(days/30); if (months < 12) return `${months}mo`;
    return `${Math.floor(months/12)}y`;
  }

  // Start
  const profile = await loadProfileJson();
  if (profile) {
    renderProfile(profile);
  }

  // Determine GitHub username: prefer profile.contact.github or profile.github, else default
  let githubUser = defaultUsername;
  if (profile) {
    if (profile.github) githubUser = profile.github;
    else if (profile.contact && profile.contact.github) githubUser = profile.contact.github;
  }
  await loadRepos(githubUser);

})();